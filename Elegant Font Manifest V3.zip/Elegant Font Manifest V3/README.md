# BetterFont

Chrome extension to aggressively font replacement. Say goodbye to your ancient design fonts right now.

## Features

Published to https://chrome.google.com/webstore/detail/better-font-on-windows/mhppkgcpdimcnbenbdbodaceilidgmfp?hl=en-US
